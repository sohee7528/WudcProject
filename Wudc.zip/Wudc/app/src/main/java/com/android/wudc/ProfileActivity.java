package com.android.wudc;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import de.hdodenhof.circleimageview.CircleImageView;


public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        TextView name = findViewById(R.id.name);
        ImageButton rename= findViewById(R.id.rename);


        /*Intent inIntent = getIntent();
        String Name = inIntent.getStringExtra("Name");
        name.setText(Name);*/

        Intent inIntent = getIntent();
        String Data = inIntent.getStringExtra("Data");
        name.setText(Data);

        rename.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //profile2로 화면전환
                Intent intent = new Intent(ProfileActivity.this, Profile2Activity.class);
                startActivity(intent);
            }
        });
        /*
        CircleImageView profileImage = findViewById(R.id.profileImage);
        ImageButton tab2 = findViewById(R.id.tab2);



        //Uri selectedImageUri = Uri.parse(bundle.getString("uri"));
        //profileImage.setImageURI(selectedImageUri);

        byte[] byteArray = getIntent().getByteArrayExtra("image");
        Bitmap bitmap = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);

        profileImage.setImageBitmap(bitmap);
 */



        /*tab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });*/

    }
}